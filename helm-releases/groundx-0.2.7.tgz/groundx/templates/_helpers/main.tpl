{{- define "groundx.ns" -}}
{{ .Values.namespace | default "eyelevel" }}
{{- end }}

{{- define "groundx.admin.apiKey" -}}
{{- $b := .Values.admin | default dict -}}
{{- (dig "apiKey" "" $b) | trim -}}
{{- end }}

{{- define "groundx.admin.email" -}}
{{- $b := .Values.admin | default dict -}}
{{- dig "email" "" $b -}}
{{- end }}

{{- define "groundx.admin.password" -}}
{{- $b := .Values.admin | default dict -}}
{{- dig "password" "" $b -}}
{{- end }}

{{- define "groundx.admin.username" -}}
{{- $b := .Values.admin | default dict -}}
{{- (dig "username" "" $b) | trim -}}
{{- end }}

{{- define "groundx.cognito.mode" -}}
{{- $b := .Values.cognito | default dict -}}
{{- (dig "mode" "" $b) | trim -}}
{{- end }}

{{- define "groundx.cognito.clientId" -}}
{{- $b := .Values.cognito | default dict -}}
{{- (dig "clientId" "" $b) | trim -}}
{{- end }}

{{- define "groundx.cognito.clientSecret" -}}
{{- $b := .Values.cognito | default dict -}}
{{- dig "clientSecret" "" $b -}}
{{- end }}

{{- define "groundx.cognito.poolId" -}}
{{- $b := .Values.cognito | default dict -}}
{{- (dig "poolId" "" $b) | trim -}}
{{- end }}

{{- define "groundx.cognito.region" -}}
{{- $b := .Values.cognito | default dict -}}
{{- (dig "region" "" $b) | trim -}}
{{- end }}

{{- define "groundx.busybox.image" -}}
{{- $in := .Values.busybox | default dict -}}
{{- $repoPrefix := include "groundx.imageRepository" . | trim -}}
{{- $ver := coalesce .Chart.AppVersion .Chart.Version -}}
{{- $fallback := printf "%s/eyelevel/busybox:1.0.0" $repoPrefix -}}
{{- coalesce (dig "image" "" $in) $fallback -}}
{{- end }}

{{- define "groundx.busybox.pull" -}}
{{- $in := .Values.busybox | default dict -}}
{{ dig "imagePullPolicy" (include "groundx.imagePullPolicy" .) $in }}
{{- end }}

{{- define "groundx.container.username" -}}
{{- if eq .Values.imageType "chainguard" -}}
65532
{{- else -}}
1001
{{- end -}}
{{- end }}

{{- define "groundx.cluster.hpa" -}}
{{- $b := .Values.cluster | default dict -}}
{{- dig "hpa" false $b -}}
{{- end }}

{{- define "groundx.clusterType" -}}
{{- $b := .Values.cluster | default dict -}}
{{- (dig "type" "eks" $b) | lower -}}
{{- end }}

{{- define "groundx.createSymlink" -}}
{{- $t := include "groundx.clusterType" . -}}
{{- and (ne $t "openshift") (ne $t "minikube") -}}
{{- end }}

{{- define "groundx.environment" -}}
{{ .Values.environment | default "prod" }}
{{- end }}

{{- define "groundx.licenseKey" -}}
{{ .Values.licenseKey | default "" }}
{{- end }}

{{- define "groundx.imagePullPolicy" -}}
{{- $b := .Values.cluster | default dict -}}
{{- dig "imagePullPolicy" "IfNotPresent" $b -}}
{{- end }}

{{- define "groundx.imagePullSecrets" -}}
{{- $b := .Values.cluster | default dict -}}
{{- $arr := dig "imagePullSecrets" list $b -}}
{{- $dict := dict -}}
{{- range $arr }}
  {{- $_ := set $dict . . -}}
{{- end }}
{{ $dict | toYaml }}
{{- end }}

{{- define "groundx.imageRepository" -}}
{{- $in := .Values.admin | default dict -}}
{{- $repo := dig "imageRepository" "" $in -}}
{{- if ne $repo "" -}}
{{ $repo }}
{{- else -}}
public.ecr.aws/c9r4x6y5
{{- end -}}
{{- end }}

{{- define "groundx.ingestOnly" -}}
{{- $mode := include "groundx.mode" . -}}
{{- if eq $mode "ingest" -}}
true
{{- else -}}
false
{{- end -}}
{{- end }}

{{- define "groundx.isOpenshift" -}}
{{- $t := include "groundx.clusterType" . -}}
{{- eq $t "openshift" -}}
{{- end }}

{{- define "groundx.languages" -}}
{{ .Values.languages | default (list "en") }}
{{- end }}

{{- define "groundx.logLevel" -}}
{{ .Values.logLevel | default "info" }}
{{- end }}

{{- define "groundx.mode" -}}
{{ coalesce (.Values.mode | default "all") "all" | trim | lower  }}
{{- end }}

{{- define "groundx.node.cpuMemory" -}}
{{- $b := .Values.cluster | default dict -}}
{{- $in := dig "nodeLabels" dict $b -}}
{{ dig "cpuMemory" "eyelevel-cpu-memory" $in }}
{{- end }}

{{- define "groundx.node.cpuOnly" -}}
{{- $b := .Values.cluster | default dict -}}
{{- $in := dig "nodeLabels" dict $b -}}
{{ dig "cpuOnly" "eyelevel-cpu-only" $in }}
{{- end }}

{{- define "groundx.node.gpuLayout" -}}
{{- $b := .Values.cluster | default dict -}}
{{- $in := dig "nodeLabels" dict $b -}}
{{ dig "gpuLayout" "eyelevel-gpu-layout" $in }}
{{- end }}

{{- define "groundx.node.gpuRanker" -}}
{{- $b := .Values.cluster | default dict -}}
{{- $in := dig "nodeLabels" dict $b -}}
{{ dig "gpuRanker" "eyelevel-gpu-ranker" $in }}
{{- end }}

{{- define "groundx.node.gpuSummary" -}}
{{- $b := .Values.cluster | default dict -}}
{{- $in := dig "nodeLabels" dict $b -}}
{{ dig "gpuSummary" "eyelevel-gpu-summary" $in }}
{{- end }}

{{- define "groundx.preProcessors" -}}
{{- $in := .Values.cluster | default dict -}}
{{- $pres := dig "preProcessors" list $in -}}
{{- if gt (len $pres) 0 }}
extraPreDefaults:
{{- range $pres }}
  - processorID: {{ .processorId }}
    type: {{ .type }}
{{- end }}
{{- end }}
{{- end }}

{{- define "groundx.pvClass" -}}
{{- $b := .Values.cluster | default dict -}}
{{- dig "pvClass" "eyelevel-pv" $b -}}
{{- end }}

{{- define "groundx.pvAccessMode" -}}
{{- $b := .Values.cluster | default dict -}}
{{- dig "pvAccessMode" "ReadWriteMany" $b -}}
{{- end }}

{{- define "groundx.secrets" -}}
{{- $b := .Values.cluster | default dict -}}
{{- $arr := dig "secrets" list $b -}}
{{- $dict := dict -}}
{{- range $arr }}
  {{- $_ := set $dict . . -}}
{{- end }}
{{ $dict | toYaml }}
{{- end }}

{{- define "groundx.serviceAccountName" -}}
{{- $in := .Values.serviceAccount | default dict -}}
{{ dig "name" "" $in }}
{{- end }}

{{- define "groundx.validApiKeys" -}}
{{- $b := .Values.cluster | default dict -}}
{{- dig "validApiKeys" list $b -}}
{{- end }}

{{- define "groundx.disruptionBudget.warnings" -}}
{{- $hpa := include "groundx.hpa" . | fromYaml | default dict -}}
{{- $keys := dict -}}
{{- range $list := list "groundx.api.services" "groundx.celery.process.services" "groundx.golang.services" "groundx.inference.services" -}}
  {{- range $k, $v := (include $list $ | fromYaml | default dict) -}}
    {{- $_ := set $keys $k $k -}}
  {{- end -}}
{{- end -}}
{{- if ne (include "groundx.metrics.create" .) "false" -}}
  {{- $_ := set $keys "metrics" "metrics" -}}
{{- end -}}
{{- $out := list -}}
{{- range $k := keys $keys | sortAlpha -}}
  {{- $s := include (printf "groundx.%s.settings" $k) $ | fromYaml | default dict -}}
  {{- $pdb := get $s "disruptionBudget" | default dict -}}
  {{- if dig "enabled" false $pdb -}}
    {{- $rp := get $s "replicas" | default dict -}}
    {{- $autoscaled := hasKey $hpa $k -}}
    {{- $min := ternary (dig "min" 1 $rp) (dig "desired" 1 $rp) $autoscaled | int -}}
    {{- if lt $min 2 -}}
      {{- $out = append $out (printf "WARNING: %s has a disruption budget (minAvailable 1) but its %s is %d, so a node drain can be blocked until it scales up or is deleted. Set replicas.%s to 2 or more." (get $s "name") (ternary "autoscaling minimum (replicas.min)" "replica count (replicas.desired)" $autoscaled) $min (ternary "min" "desired" $autoscaled)) -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- dict "warnings" $out | toYaml -}}
{{- end }}
