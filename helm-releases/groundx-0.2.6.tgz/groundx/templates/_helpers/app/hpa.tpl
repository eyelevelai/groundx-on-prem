{{- define "groundx.hpa" -}}

{{- $svcs := dict -}}

{{- $services := list
  "extract.agent"
  "extract.api"
  "extract.download"
  "extract.save"
  "groundx"
  "layout.api"
  "layout.correct"
  "layout.inference"
  "layout.map"
  "layout.ocr"
  "layout.process"
  "layout.save"
  "layoutWebhook"
  "preProcess"
  "process"
  "queue"
  "ranker.api"
  "ranker.inference"
  "summary.api"
  "summary.inference"
  "summaryClient"
  "upload"
  "workspace.api"
  "workspace.cleanup"
  "workspace.command"
  "workspace.provision"
  "workspace.publish"
  "workspace.workspace"
-}}

{{- range $svc := $services }}
  {{- $tpl := printf "groundx.%s.hpa" $svc -}}
  {{- $gx := include $tpl $ | fromYaml -}}
  {{- $enabled := dig "enabled" "false" $gx | toString -}}
  {{- if eq $enabled "true" -}}
    {{- $_ := set $svcs $svc $svc -}}
  {{- end -}}
{{- end }}

{{- $svcs | toYaml -}}

{{- end }}

{{- define "groundx.hpa.cooldown" -}}
75
{{- end }}
