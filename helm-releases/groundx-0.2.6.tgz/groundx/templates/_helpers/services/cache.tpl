{{- define "groundx.cache.node" -}}
{{- $in := .Values.cache | default dict -}}
{{- $df := include "groundx.node.cpuOnly" . -}}
{{ dig "node" $df $in }}
{{- end }}

{{- define "groundx.cache.create" -}}
{{- $in := .Values.cache | default dict -}}
{{- $ex := (dig "existing" nil $in) | default dict -}}
{{- if not (empty (dig "addr" "" $ex)) -}}
false
{{- else if hasKey $in "enabled" -}}
  {{- if (dig "enabled" false $in) -}}true{{- else -}}false{{- end -}}
{{- else -}}
true
{{- end -}}
{{- end }}

{{- define "groundx.metrics.cache.create" -}}
{{- $b := .Values.cache | default dict -}}
{{- $in := (dig "metrics" nil $b) | default dict -}}
{{- if (dig "enabled" false $in) -}}
{{- $ex := (dig "existing" nil $in) | default dict -}}
{{- if not (empty (dig "addr" "" $ex)) -}}
false
{{- else -}}
{{ include "groundx.cache.create" . }}
{{- end -}}
{{- else -}}
false
{{- end -}}
{{- end }}

{{- define "groundx.cache.type" -}}
{{- $in := .Values.cache | default dict -}}
{{- $ex := (dig "existing" nil $in) | default dict -}}
{{ dig "type" "redis" $ex }}
{{- end }}

{{- define "groundx.cache.serviceName" -}}
{{- $in := .Values.cache | default dict -}}
{{ dig "serviceName" "cache" $in }}
{{- end }}

{{- define "groundx.metrics.cache.node" -}}
{{- $b := .Values.cache | default dict -}}
{{- $in := (dig "metrics" nil $b) | default dict -}}
{{- $df := include "groundx.node.cpuOnly" . -}}
{{ dig "node" $df $in }}
{{- end }}

{{- define "groundx.metrics.cache.serviceName" -}}
{{- $b := .Values.cache | default dict -}}
{{- $in := (dig "metrics" nil $b) | default dict -}}
{{ dig "serviceName" "metrics" $in }}
{{- end }}

{{- define "groundx.cache.containerPort" -}}
{{- $in := .Values.cache | default dict -}}
{{ dig "containerPort" 6379 $in }}
{{- end }}

{{- define "groundx.metrics.cache.containerPort" -}}
{{- $b := .Values.cache | default dict -}}
{{- $in := (dig "metrics" nil $b) | default dict -}}
{{ dig "containerPort" 6379 $in }}
{{- end }}

{{- define "groundx.cache.image" -}}
{{- $in := .Values.cache | default dict -}}
{{- $repoPrefix := include "groundx.imageRepository" . | trim -}}
{{- $fallback := printf "%s/eyelevel/redis:1.0.0" $repoPrefix -}}
{{- coalesce (dig "image" "" $in) $fallback -}}
{{- end }}

{{- define "groundx.metrics.cache.image" -}}
{{- $b := .Values.cache | default dict -}}
{{- $in := (dig "metrics" nil $b) | default dict -}}
{{- $repoPrefix := include "groundx.imageRepository" . | trim -}}
{{- $fallback := printf "%s/eyelevel/redis:1.0.0" $repoPrefix -}}
{{- coalesce (dig "image" "" $in) $fallback -}}
{{- end }}

{{- define "groundx.cache.imagePullPolicy" -}}
{{- $in := .Values.cache | default dict -}}
{{ dig "imagePullPolicy" (include "groundx.imagePullPolicy" .) $in }}
{{- end }}

{{- define "groundx.metrics.cache.imagePullPolicy" -}}
{{- $b := .Values.cache | default dict -}}
{{- $in := (dig "metrics" nil $b) | default dict -}}
{{ dig "imagePullPolicy" (include "groundx.imagePullPolicy" .) $in }}
{{- end }}

{{- define "groundx.cache.mountPath" -}}
{{- $in := .Values.cache | default dict -}}
{{ dig "mountPath" "/mnt/redis" $in }}
{{- end }}

{{- define "groundx.cache.persistence.enabled" -}}
{{- $in := .Values.cache | default dict -}}
{{- $pvc := dig "persistence" dict $in -}}
{{- if (dig "enabled" false $pvc) -}}true{{- else -}}false{{- end -}}
{{- end }}

{{- define "groundx.cache.persistence.capacity" -}}
{{- $in := .Values.cache | default dict -}}
{{- $pvc := dig "persistence" dict $in -}}
{{ dig "capacity" "10Gi" $pvc }}
{{- end }}

{{- define "groundx.metrics.cache.mountPath" -}}
{{- $b := .Values.cache | default dict -}}
{{- $in := (dig "metrics" nil $b) | default dict -}}
{{ dig "mountPath" "/mnt/redis" $in }}
{{- end }}

{{- define "groundx.metrics.cache.persistence.enabled" -}}
{{- $b := .Values.cache | default dict -}}
{{- $in := (dig "metrics" nil $b) | default dict -}}
{{- $pvc := dig "persistence" dict $in -}}
{{- if (dig "enabled" false $pvc) -}}true{{- else -}}false{{- end -}}
{{- end }}

{{- define "groundx.metrics.cache.persistence.capacity" -}}
{{- $b := .Values.cache | default dict -}}
{{- $in := (dig "metrics" nil $b) | default dict -}}
{{- $pvc := dig "persistence" dict $in -}}
{{ dig "capacity" "10Gi" $pvc }}
{{- end }}

{{- define "groundx.cache.replicas" -}}
{{- $b := .Values.cache | default dict -}}
{{- $in := dig "replicas" dict $b -}}
{{- if not $in }}
  {{- $in = dict "desired" 1 "max" 1 "min" 1 -}}
{{- end }}
{{- toYaml $in | nindent 0 }}
{{- end }}

{{- define "groundx.cache.serviceAccountName" -}}
{{- $b := .Values.cache | default dict -}}
{{ dig "serviceAccountName" (include "groundx.serviceAccountName" .) $b }}
{{- end }}

{{- define "groundx.metrics.cache.serviceAccountName" -}}
{{- $b := .Values.cache | default dict -}}
{{- $in := (dig "metrics" nil $b) | default dict -}}
{{ dig "serviceAccountName" (include "groundx.cache.serviceAccountName" .) $in }}
{{- end }}

{{- define "groundx.cache.addr" -}}
{{- $in := .Values.cache | default dict -}}
{{- $ex := (dig "existing" nil $in) | default dict -}}
{{- $svc := include "groundx.cache.serviceName" . -}}
{{- $ns := include "groundx.ns" . -}}
{{- coalesce (dig "addr" "" $ex) (printf "%s.%s.svc.cluster.local" $svc $ns) -}}
{{- end }}

{{- define "groundx.cache.isCluster" -}}
{{- $in := .Values.cache | default dict -}}
{{- $ex := (dig "existing" nil $in) | default dict -}}
{{- if not (empty (dig "addr" "" $ex)) -}}
{{ dig "isCluster" "true" $ex }}
{{- else -}}
{{- $rep := (include "groundx.cache.replicas" . | fromYaml) -}}
{{- $desired := int (dig "desired" 1 $rep) -}}
{{- if gt $desired 1 -}}true{{- else -}}false{{- end -}}
{{- end -}}
{{- end }}

{{- define "groundx.cache.notCluster" -}}
{{- $ic := include "groundx.cache.isCluster" . | trim | lower -}}
{{- if eq $ic "true" -}}false{{- else -}}true{{- end -}}
{{- end }}

{{- define "groundx.cache.port" -}}
{{- $in := .Values.cache | default dict -}}
{{- $ex := (dig "existing" nil $in) | default dict -}}
{{- if not (empty (dig "addr" "" $ex)) -}}
{{ dig "port" 6379 $ex }}
{{- else -}}
{{ dig "port" 6379 $in }}
{{- end -}}
{{- end }}

{{- define "groundx.cache.scheme" -}}
{{- $ic := include "groundx.cache.ssl" . -}}
{{- if eq $ic "true" -}}
rediss
{{- else -}}
redis
{{- end -}}
{{- end }}

{{- define "groundx.cache.ssl" -}}
{{- $in := .Values.cache | default dict -}}
{{- $ex := (dig "existing" nil $in) | default dict -}}
{{- if not (empty (dig "addr" "" $ex)) -}}
{{ dig "ssl" "false" $ex }}
{{- else -}}
false
{{- end -}}
{{- end }}

{{- define "groundx.metrics.cache.addr" -}}
{{- $b := .Values.cache | default dict -}}
{{- $m := (dig "metrics" nil $b) | default dict -}}
{{- $ex := dig "existing" dict $m -}}
{{- $svc := include "groundx.cache.serviceName" . -}}
{{- $msvc := include "groundx.metrics.cache.serviceName" . -}}
{{- $ns := include "groundx.ns" . -}}
{{- if (dig "enabled" false $m) -}}
  {{- coalesce (dig "addr" "" $ex) (printf "%s-%s.%s.svc.cluster.local" $svc $msvc $ns) -}}
{{- else -}}
  {{- include "groundx.cache.addr" . -}}
{{- end -}}
{{- end }}

{{- define "groundx.metrics.cache.isCluster" -}}
{{- $b := .Values.cache | default dict -}}
{{- $m := (dig "metrics" nil $b) | default dict -}}
{{- $ex := dig "existing" dict $m -}}
{{- if (dig "enabled" false $m) -}}
{{- if not (empty (dig "addr" "" $ex)) -}}
{{ dig "isCluster" "true" $ex }}
{{- else -}}
{{- $rep := (include "groundx.metrics.cache.replicas" . | fromYaml) -}}
{{- $desired := int (dig "desired" 1 $rep) -}}
{{- if gt $desired 1 -}}true{{- else -}}false{{- end -}}
{{- end -}}
{{- else -}}
{{ include "groundx.cache.isCluster" . }}
{{- end -}}
{{- end }}

{{- define "groundx.metrics.cache.notCluster" -}}
{{- $ic := include "groundx.metrics.cache.isCluster" . | trim | lower -}}
{{- if eq $ic "true" -}}false{{- else -}}true{{- end -}}
{{- end }}

{{- define "groundx.metrics.cache.port" -}}
{{- $b := .Values.cache | default dict -}}
{{- $m := (dig "metrics" nil $b) | default dict -}}
{{- $ex := dig "existing" dict $m -}}
{{- if (dig "enabled" false $m) -}}
{{- if not (empty (dig "addr" "" $ex)) -}}
{{ dig "port" 6379 $ex }}
{{- else -}}
{{ dig "port" 6379 $m }}
{{- end -}}
{{- else -}}
{{ include "groundx.cache.port" . }}
{{- end -}}
{{- end }}

{{- define "groundx.metrics.cache.scheme" -}}
{{- $ic := include "groundx.metrics.cache.ssl" . -}}
{{- if eq $ic "true" -}}
rediss
{{- else -}}
redis
{{- end -}}
{{- end }}

{{- define "groundx.metrics.cache.ssl" -}}
{{- $in := .Values.cache | default dict -}}
{{- $ex := (dig "existing" nil $in) | default dict -}}
{{- if not (empty (dig "addr" "" $ex)) -}}
{{ dig "ssl" "false" $ex }}
{{- else -}}
false
{{- end -}}
{{- end }}

{{- define "groundx.metrics.cache.replicas" -}}
{{- $b := .Values.cache | default dict -}}
{{- $m := dig "metrics" dict $b  -}}
{{- $in := dig "replicas" dict $m -}}
{{- if not $in }}
  {{- $in = dict "desired" 1 "max" 1 "min" 1 -}}
{{- end }}
{{- toYaml $in | nindent 0 }}
{{- end }}

{{- define "groundx.cache.interface" -}}
{{- $in := .Values.cache | default dict -}}
{{- dict
    "isInternal" "true"
    "port"       (include "groundx.cache.port" .)
    "ssl"        "false"
    "targetPort" (include "groundx.cache.containerPort" .)
    "timeout"    ""
    "type"       "ClusterIP"
  | toYaml -}}
{{- end }}

{{- define "groundx.metrics.cache.interface" -}}
{{- $b := .Values.cache | default dict -}}
{{- $in := (dig "metrics" nil $b) | default dict -}}
{{- dict
    "isInternal" "true"
    "port"       (include "groundx.metrics.cache.port" .)
    "ssl"        "false"
    "targetPort" (include "groundx.metrics.cache.containerPort" .)
    "timeout"    ""
    "type"       "ClusterIP"
  | toYaml -}}
{{- end }}
