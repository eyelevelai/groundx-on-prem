{{- define "groundx.search.serviceName" -}}
{{- $in := .Values.search | default dict -}}
{{ dig "serviceName" "opensearch" $in }}
{{- end }}

{{- define "groundx.search.existing" -}}
{{- $in := .Values.search | default dict -}}
{{- $ex := dig "existing" dict $in -}}
{{ not (empty (dig "url" "" $ex)) }}
{{- end }}

{{- define "groundx.search.create" -}}
{{- $md := include "groundx.mode" . -}}
{{- if eq $md "ingest" -}}
false
{{- else -}}
{{- $in := .Values.search | default dict -}}
{{- $ic := include "groundx.search.existing" . | trim | lower -}}
{{- if eq $ic "true" -}}
false
{{- else if hasKey $in "enabled" -}}
  {{- if (dig "enabled" false $in) -}}true{{- else -}}false{{- end -}}
{{- else -}}
true
{{- end -}}
{{- end -}}
{{- end }}

{{- define "groundx.search.serviceHost" -}}
{{- $ns := include "groundx.ns" . -}}
{{- $name := include "groundx.search.serviceName" . -}}
{{- printf "%s-cluster-master.%s.svc.cluster.local" $name $ns -}}
{{- end }}

{{- define "groundx.search.baseDomain" -}}
{{- $ic := include "groundx.search.existing" . | trim | lower -}}
{{- if eq $ic "true" -}}
{{- $url := include "groundx.search.baseUrl" . -}}
{{- $parts := splitList "://" $url -}}
{{- if and (kindIs "slice" $parts) (eq (len $parts) 2) -}}
{{ index $parts 1 }}
{{- else -}}
{{ $url }}
{{- end -}}
{{- else -}}
{{ include "groundx.search.serviceHost" . }}
{{- end -}}
{{- end }}

{{- define "groundx.search.baseUrl" -}}
{{- $ic := include "groundx.search.existing" . | trim | lower -}}
{{- if eq $ic "true" -}}
{{- $in := .Values.search | default dict -}}
{{- $ex := dig "existing" dict $in -}}
{{ dig "url" "" $ex }}
{{- else -}}
{{- $port := include "groundx.search.port" . -}}
{{- $svc := include "groundx.search.serviceHost" . -}}
{{ printf "https://%s:%v" $svc $port }}
{{- end -}}
{{- end }}

{{- define "groundx.search.port" -}}
{{- $ic := include "groundx.search.existing" . | trim | lower -}}
{{- if eq $ic "true" -}}
{{- $url := include "groundx.search.baseUrl" . }}
{{- $sch := "http" -}}
{{- $sparts := splitList "://" $url -}}
{{- $domain := include "groundx.search.baseUrl" . -}}
{{- if and (kindIs "slice" $sparts) (eq (len $sparts) 2) -}}
{{- $sch = index $sparts 0 -}}
{{- $domain = index $sparts 1 -}}
{{- end -}}
{{- $pparts := splitList ":" $domain -}}
{{- if and (kindIs "slice" $pparts) (eq (len $pparts) 2) -}}
{{ index $pparts 1 }}
{{- else if eq $sch "https" -}}
443
{{- else -}}
80
{{- end -}}
{{- else -}}
{{- $in := .Values.search | default dict -}}
{{ dig "port" 9200 $in }}
{{- end -}}
{{- end }}

{{- define "groundx.search.indexName" -}}
{{- $in := .Values.search | default dict -}}
{{ dig "indexName" "prod-1" $in }}
{{- end }}

{{- define "groundx.search.password" -}}
{{- if ne (include "groundx.mode" .) "ingest" -}}
{{- $in := .Values.search | default dict -}}
{{- $v := dig "password" "" $in -}}
{{- if has (sha256sum $v) (concat (list "00b9c0a93f3fa37affc9ad8c77cb6cca46b91f39c1539aeb732a59af6c6b771f") (dig "bannedPasswordHashes" (list) $in)) -}}
{{- fail "search.password must not be a published default password; choose a new password" -}}
{{- end -}}
{{ $v }}
{{- end -}}
{{- end }}

{{- define "groundx.search.privilegedPassword" -}}
{{- if ne (include "groundx.mode" .) "ingest" -}}
{{- $in := .Values.search | default dict -}}
{{- $v := dig "privilegedPassword" "" $in -}}
{{- if has (sha256sum $v) (concat (list "00b9c0a93f3fa37affc9ad8c77cb6cca46b91f39c1539aeb732a59af6c6b771f") (dig "bannedPasswordHashes" (list) $in)) -}}
{{- fail "search.privilegedPassword must not be a published default password; choose a new password" -}}
{{- end -}}
{{ $v }}
{{- end -}}
{{- end }}

{{- define "groundx.search.privilegedUsername" -}}
{{- $in := .Values.search | default dict -}}
{{ dig "privilegedUsername" "admin" $in }}
{{- end }}

{{- define "groundx.search.username" -}}
{{- $in := .Values.search | default dict -}}
{{ dig "username" "eyelevel" $in }}
{{- end }}
